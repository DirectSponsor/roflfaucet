<?php
echo 'JWT Debug Information:' . PHP_EOL;
echo '========================' . PHP_EOL;

$authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? 'Not provided';
echo 'Authorization header: ' . $authHeader . PHP_EOL;

if (strpos($authHeader, 'Bearer ') === 0) {
    $token = substr($authHeader, 7);
    echo 'Token extracted: ' . substr($token, 0, 50) . '...' . PHP_EOL;
    
    $parts = explode('.', $token);
    echo 'Token parts count: ' . count($parts) . PHP_EOL;
    
    if (count($parts) === 3) {
        $payload = json_decode(base64_decode($parts[1]), true);
        if ($payload) {
            echo 'Token payload decoded successfully' . PHP_EOL;
            echo 'User ID: ' . ($payload['sub'] ?? 'Not found') . PHP_EOL;
            echo 'Expires: ' . ($payload['exp'] ?? 'Not found') . PHP_EOL;
            echo 'Current time: ' . time() . PHP_EOL;
            echo 'Token expired: ' . (($payload['exp'] ?? 0) < time() ? 'YES' : 'NO') . PHP_EOL;
        } else {
            echo 'Failed to decode token payload' . PHP_EOL;
        }
    } else {
        echo 'Invalid token format' . PHP_EOL;
    }
} else {
    echo 'No Bearer token found' . PHP_EOL;
}
?>
