# ROFLFaucet Complete Download Plan

## Files to Download from Live Server

### 🌐 CLIENT-SIDE FILES (downloadable via HTTP)

These files can be downloaded using Firefox's "Save Page As" or wget commands:

#### HTML Pages:
```bash
# Main pages
wget https://roflfaucet.com/index.html
wget https://roflfaucet.com/about.html 
wget https://roflfaucet.com/profile.html

# Game pages (check if these exist)
wget https://roflfaucet.com/games/dice.html
wget https://roflfaucet.com/games/slots.html  
wget https://roflfaucet.com/games/wheel.html

# Alternative locations
wget https://roflfaucet.com/dice.html
wget https://roflfaucet.com/slots.html
wget https://roflfaucet.com/wheel.html
```

#### CSS Files:
```bash
wget https://roflfaucet.com/styles.css
wget https://roflfaucet.com/styles/main.css
wget https://roflfaucet.com/main.css
wget https://roflfaucet.com/mobile-layout.css
```

#### JavaScript Files:
```bash
# Core system files
wget https://roflfaucet.com/scripts/unified-balance.js
wget https://roflfaucet.com/scripts/site-utils.js  
wget https://roflfaucet.com/scripts/faucet-bridge.js

# Game files
wget https://roflfaucet.com/js/roll-game.js
wget https://roflfaucet.com/js/levels-system.js
wget https://roflfaucet.com/slots/slots.js
wget https://roflfaucet.com/wheel/wheel-minimal.js

# Alternative locations
wget https://roflfaucet.com/scripts/core/unified-balance.js
```

### 🔧 SERVER-SIDE FILES (need SSH/SCP)

These files run on the server and must be copied directly:

#### Core PHP Files:
```bash
# Main API
scp roflfaucet@roflfaucet.com:/var/www/html/api/user-data.php ./api/

# Balance APIs  
scp roflfaucet@roflfaucet.com:/var/www/html/local-faucet-api.php ./
scp roflfaucet@roflfaucet.com:/var/www/html/session-bridge.php ./
scp roflfaucet@roflfaucet.com:/var/www/html/simple-balance-api.php ./

# UserData system
scp -r roflfaucet@roflfaucet.com:/var/www/html/userdata/ ./

# Configuration
scp roflfaucet@roflfaucet.com:/var/www/html/config.php ./
```

## 🧭 Browser Method for File Discovery

**Use Firefox Developer Tools:**

1. Open https://roflfaucet.com in Firefox
2. Press F12 → Network tab  
3. Reload the page (Ctrl+F5)
4. Look for all loaded files:
   - **Document**: HTML files
   - **Stylesheet**: CSS files  
   - **Script**: JavaScript files
   - **XHR/Fetch**: API endpoints (these are PHP files)

**Record every file that loads successfully.**

## 🎯 Critical Success Test

After downloading, the system should:

1. ✅ Load the main page without errors
2. ✅ Show proper styling (CSS loaded)
3. ✅ Display balance system UI (JS loaded) 
4. ✅ Allow login attempts (even if they fail due to auth)
5. ✅ Games should load (even if functionality is broken)

## 🚨 What We're Looking For

The **authentication efficiency problem** means we need these specific files:
- `unified-balance.js` - Contains JWT authentication code
- `user-data.php` - The inefficient API that validates JWT on every call  
- `session-bridge.php` or `local-faucet-api.php` - Session-based alternatives
- `UserDataManager.php` - The flat-file data system

## 📁 Expected Directory Structure

```
/home/andy/public_html/duckdns/
├── index.html
├── about.html  
├── profile.html
├── styles.css
├── main.css
├── api/
│   └── user-data.php
├── scripts/
│   ├── unified-balance.js
│   └── site-utils.js
├── js/
│   └── roll-game.js
├── games/
│   ├── dice.html
│   ├── slots.html
│   └── wheel.html
├── userdata/
│   ├── UserDataManager.php
│   ├── balances/
│   └── profiles/
├── local-faucet-api.php
├── session-bridge.php
└── simple-balance-api.php
```

## 🔄 Download Process

1. **Start with Firefox inspection** - identify all loading files
2. **Download client files** using wget or browser "Save As"  
3. **Copy server files** using SCP
4. **Test basic loading** - does the page render?
5. **Check console** for missing file errors
6. **Download any missing files** identified in console

Once we have a working copy, we can analyze and fix the authentication efficiency issue!
