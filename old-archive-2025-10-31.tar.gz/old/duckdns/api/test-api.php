<?php
// Test script to simulate the API call locally
$_SERVER['REQUEST_METHOD'] = 'GET';
$_SERVER['HTTP_AUTHORIZATION'] = 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJyb2ZsZmF1Y2V0IiwiaWF0IjoxNzU2MzEzMTM5LCJleHAiOjE3NTYzMTY3MzksInN1YiI6IjExIiwidXNlcm5hbWUiOiJhbmR5dGVzdDEifQ.3O_QLUgfzMu5qRj7Z_aq7vqQmJmZJOOeZvfwbKmgzqA';
$_GET['action'] = 'balance';

echo "🧪 SIMULATING API CALL:\n";
echo "Action: " . $_GET['action'] . "\n";
echo "Authorization: " . $_SERVER['HTTP_AUTHORIZATION'] . "\n\n";
echo "API Response:\n";

// Include the API file
require_once 'user-data.php';
?>
