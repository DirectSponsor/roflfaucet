# Required PHP Files for Authentication System

Based on the context document analysis, these are the **critical server-side PHP files** needed to fix the JWT authentication efficiency issue:

## 🔧 Core API Files (CRITICAL)

1. **`api/user-data.php`** - The current inefficient API that validates JWT on every call
   - This is where the problem exists (validates JWT on every operation)
   - Location: `/var/www/html/api/user-data.php`
   - Command: `scp roflfaucet@roflfaucet.com:/var/www/html/api/user-data.php ./api/`

2. **`userdata/UserDataManager.php`** - The flat-file data management system
   - Location: `/var/www/html/userdata/UserDataManager.php`
   - Command: `scp -r roflfaucet@roflfaucet.com:/var/www/html/userdata/ ./`

## 🔄 Session-Based Alternatives (POTENTIAL SOLUTIONS)

3. **`session-bridge.php`** - Session management system mentioned in context
   - Location: `/var/www/html/session-bridge.php`
   - Command: `scp roflfaucet@roflfaucet.com:/var/www/html/session-bridge.php ./`

4. **`local-faucet-api.php`** - Local session-based API mentioned in context
   - Location: `/var/www/html/local-faucet-api.php`
   - Command: `scp roflfaucet@roflfaucet.com:/var/www/html/local-faucet-api.php ./`

5. **`simple-balance-api.php`** - Session-based balance API
   - Location: `/var/www/html/simple-balance-api.php`
   - Command: `scp roflfaucet@roflfaucet.com:/var/www/html/simple-balance-api.php ./`

## 📁 Data Directories

6. **`userdata/balances/`** - User balance flat files
7. **`userdata/profiles/`** - User profile flat files
8. **`api/userdata/`** - Additional user data files

## ⚠️ Why These Files Are Critical

From the context document:
- **Problem**: "The current user data system is performing JWT authentication for every single operation"
- **Evidence**: Every API call to `user-data.php` calls `getUserIdFromToken()` which decodes JWT
- **Solution**: Switch to session-based authentication after initial JWT login

## 📋 Download Commands

```bash
# Create directories
mkdir -p api userdata

# Download critical PHP files
scp roflfaucet@roflfaucet.com:/var/www/html/api/user-data.php ./api/
scp -r roflfaucet@roflfaucet.com:/var/www/html/userdata/ ./
scp roflfaucet@roflfaucet.com:/var/www/html/session-bridge.php ./
scp roflfaucet@roflfaucet.com:/var/www/html/local-faucet-api.php ./
scp roflfaucet@roflfaucet.com:/var/www/html/simple-balance-api.php ./

# Optional configuration files
scp roflfaucet@roflfaucet.com:/var/www/html/config.php ./ 2>/dev/null || echo "config.php not accessible"
```

## 🎯 Test Plan After Download

Once these files are downloaded:

1. **Test basic loading**: Visit `https://satoshihost.ddns.net/projects/duckdns/`
2. **Check browser console** for missing file errors
3. **Test login button** - should redirect to auth server
4. **Examine authentication flow** - identify where JWT validation happens on every call
5. **Implement session-based fix** - modify to use sessions after initial JWT validation

The goal is to have JWT validation happen **once** during login, then use PHP sessions for subsequent operations.
