# DuckDNS ROFLFaucet Development - Project Context
*Created: August 26, 2025*

## 🎯 PROJECT GOAL

Build a **truly portable user data system** using the ROFLFaucet site as a test case. The system must work identically on any server (local, live, anywhere) with minimal configuration.

## 🚨 THE PROBLEM WE'RE SOLVING

The existing ROFLFaucet site has a **server-dependent user data system** that:
- ✅ Works correctly on live server (`roflfaucet.com`)
- ❌ Breaks repeatedly in local development
- ❌ Has hidden environmental dependencies
- ❌ Cannot be safely modified without risking live environment

**Root Issue**: We cannot safely develop/test locally because local changes get deployed to production, risking breaking the working live system.

## 💡 THE SOLUTION

Create a **separate development environment** (`duckdns` directory) where we can:
1. **Build a portable user data system** from scratch
2. **Test safely** without affecting the live system
3. **Make it work locally first** then deploy with confidence
4. **Create a reusable system** that can be dropped into any website

## 🏗️ PROJECT ARCHITECTURE

### Current System Analysis
The live ROFLFaucet system has these components:

**Frontend (JavaScript):**
- `scripts/unified-balance.js` - Main balance system with guest/member modes
- `scripts/site-utils.js` - JWT processing and UI utilities
- Game-specific JS files (slots, dice, wheel)

**Backend (PHP):**
- `api/user-data.php` - Main API for member data operations
- `userdata/UserDataManager.php` - Flat-file data manager
- `simple-balance-api.php` - Session-based balance API
- Various game APIs

**Data Storage:**
- `userdata/balances/` - User balance flat files
- `userdata/profiles/` - User profile flat files  
- `api/userdata/` - Additional user data files

### Portability Requirements

For a system to be truly portable, it must:

1. **Auto-detect environment** (local vs production)
2. **Self-configure paths and URLs** 
3. **Work with minimal setup** (just file permissions)
4. **Handle different server configurations**
5. **Maintain consistent behavior** across environments

## 📂 CURRENT DIRECTORY STRUCTURE

```
/home/andy/warp/projects/duckdns/
├── index.html                 # Main homepage
├── about.html                 # About page  
├── profile.html               # User profile page
├── games/                     # Game pages
│   ├── dice.html
│   ├── slots.html  
│   └── wheel.html
├── api/                       # Backend APIs
│   ├── user-data.php
│   └── userdata/              # User data files
├── userdata/                  # Main user data system
│   ├── UserDataManager.php
│   ├── balances/
│   └── profiles/
├── scripts/                   # Frontend JavaScript
│   ├── unified-balance.js
│   ├── site-utils.js
│   └── core/                  # Core utilities
├── styles/                    # CSS files
└── config.php                 # Server configuration
```

## 🎯 DEVELOPMENT PHASES

### Phase 1: Setup & Analysis ✅ COMPLETE
- [x] Create duckdns development directory
- [x] Copy complete live server files via SSH
- [x] Document current system architecture

### Phase 2: Environment Configuration
- [ ] Create auto-configuration system for different environments
- [ ] Build environment detection (local vs production)
- [ ] Configure paths and URLs dynamically
- [ ] Set up duckdns domain for testing

### Phase 3: User Data System Enhancement  
- [ ] Improve UserDataManager for better portability
- [ ] Add comprehensive error handling and logging
- [ ] Implement automatic directory creation
- [ ] Add data validation and corruption recovery

### Phase 4: Frontend Integration
- [ ] Update JavaScript to work with portable backend
- [ ] Add environment-specific configuration
- [ ] Ensure consistent behavior across environments
- [ ] Test all game integrations

### Phase 5: Testing & Validation
- [ ] Test system locally (duckdns domain)  
- [ ] Verify member authentication works
- [ ] Test all games and balance operations
- [ ] Compare behavior with live system

### Phase 6: Documentation & Deployment
- [ ] Document integration process
- [ ] Create setup scripts for new sites
- [ ] Write deployment guide
- [ ] Test deployment to live environment

## 🔑 SUCCESS CRITERIA

The portable system will be considered successful when:

- ✅ **Works identically on local and live servers**
- ✅ **Member authentication and balances function correctly** 
- ✅ **All games integrate properly with user data**
- ✅ **Can be deployed to new sites with minimal configuration**
- ✅ **Self-configures based on environment detection**
- ✅ **Handles errors gracefully with comprehensive logging**

## 🛠️ TECHNICAL REQUIREMENTS

### Server Requirements:
- PHP 7.4+ (for modern features)
- Web server (Apache/Nginx)
- File system write permissions
- Optional: Domain/subdomain for testing

### Dependencies:
- JWT library (or simple base64 decoding)
- File locking capabilities
- JSON support in PHP

### External Dependencies:
- JWT authentication server (`auth.directsponsor.org`)
- No database required (flat-file only)

## 📝 DEVELOPMENT NOTES

### Key Insights from Live System:
1. **JWT Authentication works correctly** - don't break this
2. **Unified balance system is solid** - preserve the architecture
3. **Flat-file storage works** but needs better error handling  
4. **Game integration is complex** - maintain existing interfaces

### What Needs Improvement:
1. **Path management** - hardcoded paths cause issues
2. **Error handling** - system fails silently in many cases
3. **Environment detection** - no auto-configuration
4. **Logging** - difficult to debug when things break
5. **Data validation** - corruption causes silent failures

## 🚀 NEXT STEPS

1. **Set up local web server** for duckdns directory
2. **Configure domain/subdomain** for local testing
3. **Test current system locally** to identify specific failure points
4. **Begin building portable configuration system**

---

*This project represents a strategic shift from "fix broken local environment" to "build portable system that works everywhere". Success here will enable confident development and deployment of user data features across multiple sites.*
