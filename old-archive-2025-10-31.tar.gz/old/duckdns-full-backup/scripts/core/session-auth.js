// Phase 2 Session-Based Authentication Handler
// Pure authentication only - no balance logic

console.log('🔐 Phase 2 Session Auth loading...');

class SessionAuth {
    constructor() {
        this.isLoggedIn = !!localStorage.getItem('jwt_token');
        console.log(`🔐 Session Auth initialized - ${this.isLoggedIn ? 'authenticated' : 'guest'}`);
    }
    
    // Handle JWT callback from auth server
    handleJWTCallback() {
        const urlParams = new URLSearchParams(window.location.search);
        const jwt = urlParams.get('jwt');
        
        if (jwt) {
            console.log('🔑 JWT received from auth server');
            localStorage.setItem('jwt_token', jwt);
            this.isLoggedIn = true;
            
            // Clean up URL
            const cleanUrl = window.location.pathname + window.location.hash;
            history.replaceState({}, document.title, cleanUrl);
            
            // Update login button immediately
            this.updateLoginButton();
            
            // Force balance system to reinitialize with new login status
            // Use a small delay to ensure the balance system is ready
            setTimeout(() => {
                if (typeof fileBasedBalance !== 'undefined' && fileBasedBalance.init) {
                    fileBasedBalance.init();
                } else if (window.fileBasedBalance && window.fileBasedBalance.init) {
                    window.fileBasedBalance.init();
                }
            }, 100);
            
            console.log('✅ Authentication successful');
            return true;
        }
        return false;
    }
    
    // Handle login button click
    handleLoginClick() {
        if (this.isLoggedIn) {
            // Already logged in - show logout confirm
            if (confirm('Are you sure you want to logout?')) {
                this.handleLogout();
            }
        } else {
            // Redirect to auth server
            const currentUrl = window.location.href;
            const authUrl = `http://auth.directsponsor.org/jwt-login.php?redirect_uri=${encodeURIComponent(currentUrl)}`;
            console.log('🔐 Redirecting to auth server');
            window.location.href = authUrl;
        }
    }
    
    // Handle logout
    handleLogout() {
        console.log('🚪 Logging out...');
        
        // Clear JWT token
        localStorage.removeItem('jwt_token');
        this.isLoggedIn = false;
        
        // Clear balance system data
        if (window.simpleBalance && window.simpleBalance.clearAllData) {
            window.simpleBalance.clearAllData();
        }
        
        this.updateLoginButton();
        console.log('✅ Logged out successfully');
        
        // Refresh the page to clear any session data
        window.location.reload();
    }
    
    // Update login button display
    updateLoginButton() {
        const loginBtn = document.getElementById('login-btn');
        if (!loginBtn) return;
        
        if (this.isLoggedIn) {
            // Try to get username from JWT
            const username = this.getUsernameFromToken();
            loginBtn.textContent = username ? `👤 ${username}` : '👤 User';
            loginBtn.className = 'header-auth-btn member';
        } else {
            loginBtn.textContent = 'Login';
            loginBtn.className = 'header-auth-btn';
        }
    }
    
    // Get username from JWT token
    getUsernameFromToken() {
        try {
            const token = localStorage.getItem('jwt_token');
            if (!token) return null;
            
            const payload = JSON.parse(atob(token.split('.')[1]));
            return payload.username || payload.name || null;
        } catch (e) {
            console.warn('Could not decode username from JWT');
            return null;
        }
    }
    
    // Check if user is authenticated
    isAuthenticated() {
        return this.isLoggedIn;
    }
    
    // Get JWT token for API calls
    getToken() {
        return localStorage.getItem('jwt_token');
    }
}

// Global instance
window.sessionAuth = new SessionAuth();

// Wire up login button when DOM loads
document.addEventListener('DOMContentLoaded', () => {
    // Handle JWT callback first
    window.sessionAuth.handleJWTCallback();
    
    // Wire up login button
    const loginBtn = document.getElementById('login-btn');
    if (loginBtn) {
        loginBtn.addEventListener('click', () => window.sessionAuth.handleLoginClick());
    }
    
    // Initial button update
    window.sessionAuth.updateLoginButton();
});

console.log('🔐 Phase 2 Session Auth ready!');
