// Ultra-Simple Balance System
// No complex session APIs, just direct localStorage for guests and simple PHP sessions for members

class SimpleBalance {
    constructor() {
        this.isLoggedIn = !!localStorage.getItem('jwt_token');
        console.log(`💰 Simple Balance System initialized for ${this.isLoggedIn ? 'member' : 'guest'}`);
    }
    
    // Get balance - simple and reliable
    async getBalance() {
        if (this.isLoggedIn) {
            return await this.getMemberBalance();
        } else {
            return this.getGuestBalance();
        }
    }
    
    // Member balance from PHP session
    async getMemberBalance() {
        try {
            const response = await fetch('/simple-balance-api.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: new URLSearchParams({
                    action: 'get_balance',
                    jwt: localStorage.getItem('jwt_token')
                })
            });
            
            if (response.ok) {
                const data = await response.json();
                if (data.success) {
                    console.log('✅ Member balance:', data.balance);
                    return parseFloat(data.balance);
                }
            }
            
            console.log('⚠️ Member balance API failed, using fallback');
            return 0;
            
        } catch (error) {
            console.error('💥 Member balance error:', error);
            return 0;
        }
    }
    
    // Guest balance from localStorage
    getGuestBalance() {
        const balance = parseFloat(localStorage.getItem('guest_balance') || '0');
        console.log('👤 Guest balance:', balance);
        return balance;
    }
    
    // Add balance
    async addBalance(amount, source = 'unknown') {
        if (this.isLoggedIn) {
            return await this.addMemberBalance(amount, source);
        } else {
            return this.addGuestBalance(amount, source);
        }
    }
    
    // Add member balance
    async addMemberBalance(amount, source) {
        try {
            const response = await fetch('/simple-balance-api.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: new URLSearchParams({
                    action: 'add_balance',
                    amount: amount,
                    source: source,
                    jwt: localStorage.getItem('jwt_token')
                })
            });
            
            if (response.ok) {
                const data = await response.json();
                if (data.success) {
                    console.log('✅ Member balance added:', amount, 'New balance:', data.new_balance);
                    return { success: true, balance: parseFloat(data.new_balance) };
                } else {
                    console.log('⚠️ Member add failed:', data.error);
                    return { success: false, error: data.error };
                }
            }
            
            console.log('⚠️ Member add API failed');
            return { success: false, error: 'API failed' };
            
        } catch (error) {
            console.error('💥 Member add error:', error);
            return { success: false, error: 'Network error' };
        }
    }
    
    // Add guest balance
    addGuestBalance(amount, source) {
        const currentBalance = this.getGuestBalance();
        const newBalance = currentBalance + amount;
        localStorage.setItem('guest_balance', newBalance.toString());
        
        console.log('✅ Guest balance added:', amount, 'New balance:', newBalance);
        return { success: true, balance: newBalance };
    }
    
    // Subtract balance
    async subtractBalance(amount, source = 'unknown') {
        if (this.isLoggedIn) {
            return await this.subtractMemberBalance(amount, source);
        } else {
            return this.subtractGuestBalance(amount, source);
        }
    }
    
    // Subtract member balance
    async subtractMemberBalance(amount, source) {
        try {
            const response = await fetch('/simple-balance-api.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: new URLSearchParams({
                    action: 'subtract_balance',
                    amount: amount,
                    source: source,
                    jwt: localStorage.getItem('jwt_token')
                })
            });
            
            if (response.ok) {
                const data = await response.json();
                if (data.success) {
                    console.log('✅ Member balance subtracted:', amount, 'New balance:', data.new_balance);
                    return { success: true, balance: parseFloat(data.new_balance) };
                } else {
                    console.log('⚠️ Member subtract failed:', data.error);
                    return { success: false, error: data.error, balance: parseFloat(data.current_balance || 0) };
                }
            }
            
            console.log('⚠️ Member subtract API failed');
            return { success: false, error: 'API failed' };
            
        } catch (error) {
            console.error('💥 Member subtract error:', error);
            return { success: false, error: 'Network error' };
        }
    }
    
    // Subtract guest balance
    subtractGuestBalance(amount, source) {
        const currentBalance = this.getGuestBalance();
        if (currentBalance < amount) {
            console.log('❌ Insufficient guest balance');
            return { success: false, balance: currentBalance, error: 'Insufficient balance' };
        }
        
        const newBalance = currentBalance - amount;
        localStorage.setItem('guest_balance', newBalance.toString());
        
        console.log('✅ Guest balance subtracted:', amount, 'New balance:', newBalance);
        return { success: true, balance: newBalance };
    }
    
    // Clear all data on logout
    clearAllData() {
        localStorage.removeItem('guest_balance');
        console.log('🗄️ All balance data cleared');
    }
}

// Global instance
window.simpleBalance = new SimpleBalance();

// Global convenience functions (replacing the old unified balance functions)
window.getBalance = () => window.simpleBalance.getBalance();
window.addBalance = (amount, source, description) => window.simpleBalance.addBalance(amount, source);
window.subtractBalance = (amount, source, description) => window.simpleBalance.subtractBalance(amount, source);

// Update balance displays
window.updateBalanceDisplays = async () => {
    const balance = await window.simpleBalance.getBalance();
    
    // Update all balance display elements
    const balanceElements = document.querySelectorAll('.balance, #current-balance, #balance, #user-balance');
    balanceElements.forEach(element => {
        element.textContent = Math.floor(balance);
    });
    
    console.log('💰 Balance displays updated:', Math.floor(balance));
};

// Alias for compatibility with faucet-bridge.js
window.updateBalanceDisplay = window.updateBalanceDisplays;

// Auto-update displays when page loads
document.addEventListener('DOMContentLoaded', () => {
    setTimeout(() => {
        updateBalanceDisplays();
    }, 100);
    
    // Update every 5 seconds
    setInterval(updateBalanceDisplays, 5000);
});

console.log('🔧 Simple Balance System ready!');
