<?php
/**
 * Example Avatar Upload System
 * 
 * Shows how to integrate avatar uploads with the file-based user data system
 */

require_once 'user-data-manager.php';

// Handle avatar upload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['avatar'])) {
    // Validate JWT and get username (same as existing system)
    $headers = getallheaders();
    $token = $headers['Authorization'] ?? null;
    $username = validateJWT($token); // Your existing JWT validation
    
    if (!$username) {
        http_response_code(401);
        echo json_encode(['error' => 'Authentication required']);
        exit;
    }
    
    $file = $_FILES['avatar'];
    
    // Validate file
    if ($file['error'] !== UPLOAD_ERR_OK) {
        echo json_encode(['error' => 'Upload failed']);
        exit;
    }
    
    // Check file type
    $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
    if (!in_array($file['type'], $allowedTypes)) {
        echo json_encode(['error' => 'Invalid file type']);
        exit;
    }
    
    // Create uploads directory if needed
    $uploadDir = 'uploads/avatars/';
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }
    
    // Generate unique filename
    $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
    $filename = $username . '_' . time() . '.' . $extension;
    $filepath = $uploadDir . $filename;
    
    // Move uploaded file
    if (move_uploaded_file($file['tmp_name'], $filepath)) {
        // Update user's avatar in their text file
        $userManager = new UserDataManager();
        
        // Get current profile data
        $userData = $userManager->getUser($username);
        
        // Delete old avatar if it's not default
        if ($userData['avatar'] !== 'default.png' && file_exists($userData['avatar'])) {
            unlink($userData['avatar']);
        }
        
        // Update profile with new avatar path
        $profileData = $userData['profile'];
        $userManager->updateProfile($username, $profileData);
        
        // Update avatar in metadata (you'd need to add this method)
        // For now, we can update the whole user data
        $userData['avatar'] = $filepath;
        
        // Add activity log
        $userManager->addActivity($username, "Avatar updated: $filename");
        
        echo json_encode([
            'success' => true, 
            'avatar_url' => $filepath,
            'message' => 'Avatar uploaded successfully'
        ]);
    } else {
        echo json_encode(['error' => 'Failed to save file']);
    }
}

// Simple JWT validation (you'd use your existing function)
function validateJWT($token) {
    // Your existing JWT validation logic here
    // Return username if valid, null if invalid
    return 'testuser'; // Placeholder
}
?>
