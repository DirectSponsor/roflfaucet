<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit;
}

// Super simple: get user ID
$userId = $_GET['user_id'] ?? $_POST['user_id'] ?? null;
$action = $_GET['action'] ?? $_POST['action'] ?? 'balance';

if (!$userId) {
    echo json_encode(['error' => 'user_id required']);
    exit;
}

// Simple file paths
$balanceFile = "userdata/balances/{$userId}.txt";

switch ($action) {
    case 'balance':
        // Read balance file
        if (file_exists($balanceFile)) {
            $data = json_decode(file_get_contents($balanceFile), true);
            $balance = $data['balance'] ?? 0;
        } else {
            $balance = 0;
        }
        echo json_encode(['success' => true, 'balance' => $balance]);
        break;
        
    case 'add_balance':
        $amount = floatval($_POST['amount'] ?? 0);
        
        // Read current balance
        if (file_exists($balanceFile)) {
            $data = json_decode(file_get_contents($balanceFile), true);
            $balance = $data['balance'] ?? 0;
        } else {
            $balance = 0;
            $data = [];
        }
        
        // Add amount
        $balance += $amount;
        $data['balance'] = $balance;
        $data['last_updated'] = time();
        
        // Write back
        file_put_contents($balanceFile, json_encode($data));
        
        echo json_encode(['success' => true, 'new_balance' => $balance]);
        break;
        
    default:
        echo json_encode(['error' => 'Invalid action']);
}
?>
