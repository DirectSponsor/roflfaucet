<?php
/**
 * User Data API - File-based user data system endpoint
 * 
 * Replaces session-based balance system with persistent file-based storage
 * that can be synced across servers via Syncthing.
 */

require_once 'user-data-manager.php';

// Enable CORS for local development
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Content-Type: application/json");

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Basic JWT validation function (simplified)
function validateJWT($token) {
    if (empty($token)) return null;
    
    // Remove "Bearer " prefix if present
    if (strpos($token, 'Bearer ') === 0) {
        $token = substr($token, 7);
    }
    
    // Simple JWT decode (you should use a proper JWT library in production)
    $parts = explode('.', $token);
    if (count($parts) !== 3) return null;
    
    try {
        $payload = json_decode(base64_decode($parts[1]), true);
        return $payload['username'] ?? null;
    } catch (Exception $e) {
        return null;
    }
}

// Get username from JWT token
function getAuthenticatedUser() {
    $headers = getallheaders();
    $token = $headers['Authorization'] ?? $_SERVER['HTTP_AUTHORIZATION'] ?? null;
    return validateJWT($token);
}

// Initialize user data manager
$userManager = new UserDataManager();

// Get request method and action
$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? $_POST['action'] ?? '';

try {
    switch ($method) {
        case 'GET':
            handleGetRequest($action, $userManager);
            break;
            
        case 'POST':
            handlePostRequest($action, $userManager);
            break;
            
        default:
            http_response_code(405);
            echo json_encode(['error' => 'Method not allowed']);
            break;
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Server error: ' . $e->getMessage()]);
}

function handleGetRequest($action, $userManager) {
    switch ($action) {
        case 'balance':
            $username = getAuthenticatedUser();
            if (!$username) {
                http_response_code(401);
                echo json_encode(['error' => 'Authentication required']);
                return;
            }
            
            $balance = $userManager->getBalance($username);
            echo json_encode(['balance' => $balance, 'username' => $username]);
            break;
            
        case 'profile':
            $username = getAuthenticatedUser();
            if (!$username) {
                http_response_code(401);
                echo json_encode(['error' => 'Authentication required']);
                return;
            }
            
            $userData = $userManager->getUser($username);
            if ($userData) {
                echo json_encode([
                    'username' => $userData['username'],
                    'balance' => $userData['balance'],
                    'avatar' => $userData['avatar'],
                    'profile' => $userData['profile'],
                    'created' => $userData['metadata']['created'] ?? 'Unknown'
                ]);
            } else {
                http_response_code(404);
                echo json_encode(['error' => 'User not found']);
            }
            break;
            
        case 'activity':
            $username = getAuthenticatedUser();
            if (!$username) {
                http_response_code(401);
                echo json_encode(['error' => 'Authentication required']);
                return;
            }
            
            $userData = $userManager->getUser($username);
            if ($userData) {
                $activities = array_slice($userData['activity'], -20); // Last 20 activities
                echo json_encode(['activities' => $activities]);
            } else {
                http_response_code(404);
                echo json_encode(['error' => 'User not found']);
            }
            break;
            
        case 'status':
            // System status - no auth required for debugging
            $status = $userManager->getSystemStatus();
            echo json_encode($status);
            break;
            
        default:
            http_response_code(400);
            echo json_encode(['error' => 'Invalid action for GET request']);
            break;
    }
}

function handlePostRequest($action, $userManager) {
    $input = json_decode(file_get_contents('php://input'), true);
    
    switch ($action) {
        case 'update_balance':
            $username = getAuthenticatedUser();
            if (!$username) {
                http_response_code(401);
                echo json_encode(['error' => 'Authentication required']);
                return;
            }
            
            $amount = floatval($input['amount'] ?? 0);
            $operation = $input['operation'] ?? 'set'; // set, add, subtract
            $description = $input['description'] ?? '';
            
            if ($amount < 0 && $operation !== 'subtract') {
                http_response_code(400);
                echo json_encode(['error' => 'Invalid amount']);
                return;
            }
            
            $success = $userManager->updateBalance($username, $amount, $operation, $description);
            if ($success) {
                $newBalance = $userManager->getBalance($username);
                echo json_encode(['success' => true, 'balance' => $newBalance]);
            } else {
                http_response_code(500);
                echo json_encode(['error' => 'Failed to update balance']);
            }
            break;
            
        case 'update_profile':
            $username = getAuthenticatedUser();
            if (!$username) {
                http_response_code(401);
                echo json_encode(['error' => 'Authentication required']);
                return;
            }
            
            $profileData = $input['profile'] ?? [];
            if (empty($profileData)) {
                http_response_code(400);
                echo json_encode(['error' => 'No profile data provided']);
                return;
            }
            
            $success = $userManager->updateProfile($username, $profileData);
            if ($success) {
                echo json_encode(['success' => true]);
            } else {
                http_response_code(500);
                echo json_encode(['error' => 'Failed to update profile']);
            }
            break;
            
        case 'add_activity':
            $username = getAuthenticatedUser();
            if (!$username) {
                http_response_code(401);
                echo json_encode(['error' => 'Authentication required']);
                return;
            }
            
            $activity = $input['activity'] ?? '';
            if (empty($activity)) {
                http_response_code(400);
                echo json_encode(['error' => 'No activity provided']);
                return;
            }
            
            $success = $userManager->addActivity($username, $activity);
            if ($success) {
                echo json_encode(['success' => true]);
            } else {
                http_response_code(500);
                echo json_encode(['error' => 'Failed to add activity']);
            }
            break;
            
        default:
            http_response_code(400);
            echo json_encode(['error' => 'Invalid action for POST request']);
            break;
    }
}
?>
