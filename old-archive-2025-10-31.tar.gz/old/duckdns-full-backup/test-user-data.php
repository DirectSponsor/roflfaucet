<?php
/**
 * Test script for the file-based user data system
 * 
 * Run this script to verify that user files are created and updated correctly.
 * Access via browser: http://your-site/test-user-data.php
 */

require_once 'user-data-manager.php';

echo "<h1>File-based User Data System Test</h1>";
echo "<pre>";

// Initialize the user data manager
$userManager = new UserDataManager();

echo "=== Testing User Data Manager ===\n\n";

// Test creating a new user
echo "1. Creating new user 'testuser'...\n";
$userData = $userManager->getUser('testuser');
print_r($userData);
echo "\n";

// Test updating balance
echo "2. Adding 500 to balance...\n";
$success = $userManager->updateBalance('testuser', 500, 'add', 'Test deposit');
echo "Success: " . ($success ? 'YES' : 'NO') . "\n";

$newBalance = $userManager->getBalance('testuser');
echo "New balance: $newBalance\n\n";

// Test subtracting balance
echo "3. Subtracting 100 from balance...\n";
$success = $userManager->updateBalance('testuser', 100, 'subtract', 'Test withdrawal');
echo "Success: " . ($success ? 'YES' : 'NO') . "\n";

$newBalance = $userManager->getBalance('testuser');
echo "New balance: $newBalance\n\n";

// Test updating profile
echo "4. Updating user profile...\n";
$profileData = [
    'display_name' => 'Test User',
    'favorite_game' => 'Slots',
    'timezone' => 'UTC'
];
$success = $userManager->updateProfile('testuser', $profileData);
echo "Success: " . ($success ? 'YES' : 'NO') . "\n\n";

// Test adding activity
echo "5. Adding activity log entry...\n";
$success = $userManager->addActivity('testuser', 'Played slots game');
echo "Success: " . ($success ? 'YES' : 'NO') . "\n\n";

// Show final user data
echo "6. Final user data:\n";
$finalData = $userManager->getUser('testuser');
print_r($finalData);
echo "\n";

// Show system status
echo "7. System Status:\n";
$status = $userManager->getSystemStatus();
print_r($status);
echo "\n";

// List all user files
echo "8. User files created:\n";
$userFiles = glob('user-data/users/*.txt');
foreach ($userFiles as $file) {
    echo "- " . basename($file) . "\n";
}
echo "\n";

// Show contents of test user file
echo "9. Contents of testuser.txt:\n";
$userFile = 'user-data/users/testuser.txt';
if (file_exists($userFile)) {
    echo file_get_contents($userFile);
} else {
    echo "File not found!\n";
}

echo "</pre>";

echo "<h2>API Test Links</h2>";
echo "<p>Test the API endpoints (you'll need a valid JWT token for authenticated endpoints):</p>";
echo "<ul>";
echo "<li><a href='user-data-api.php?action=status'>System Status</a> (no auth required)</li>";
echo "<li><a href='user-data-api.php?action=balance'>Get Balance</a> (auth required)</li>";
echo "<li><a href='user-data-api.php?action=profile'>Get Profile</a> (auth required)</li>";
echo "<li><a href='user-data-api.php?action=activity'>Get Activity</a> (auth required)</li>";
echo "</ul>";

echo "<h2>File System Structure</h2>";
echo "<pre>";
echo "user-data/\n";
echo "├── users/          (user data files)\n";
echo "├── locks/          (file locks)\n";
echo "├── logs/           (system logs)\n";
echo "└── sync-queue/     (future Syncthing priority queue)\n\n";

// Show directory contents
function showDir($dir, $level = 0) {
    $indent = str_repeat('  ', $level);
    if (is_dir($dir)) {
        $files = scandir($dir);
        foreach ($files as $file) {
            if ($file != '.' && $file != '..') {
                echo $indent . $file;
                $path = $dir . '/' . $file;
                if (is_dir($path)) {
                    echo "/\n";
                    showDir($path, $level + 1);
                } else {
                    echo " (" . filesize($path) . " bytes)\n";
                }
            }
        }
    }
}

if (is_dir('user-data')) {
    showDir('user-data');
} else {
    echo "user-data directory not found!\n";
}

echo "</pre>";
?>
