<?php
/**
 * Ultra-Simple Faucet API
 * Works with the new simple balance system
 */

session_start();
header('Content-Type: application/json');

// Simple JWT validation function
function validateJWT($jwt) {
    if (!$jwt) return false;
    
    try {
        $parts = explode('.', $jwt);
        if (count($parts) !== 3) return false;
        
        // For now, just decode payload without signature validation
        $payload = json_decode(base64_decode($parts[1]), true);
        
        // Check if token has expired
        if (isset($payload['exp']) && $payload['exp'] < time()) {
            return false;
        }
        
        return $payload;
    } catch (Exception $e) {
        return false;
    }
}

// Get action
$action = $_POST['action'] ?? $_GET['action'] ?? 'status';

try {
    switch ($action) {
        case 'status':
            $jwt = $_POST['jwt'] ?? $_GET['jwt'] ?? '';
            $payload = validateJWT($jwt);
            
            if ($payload) {
                // Member mode
                $lastClaim = $_SESSION['member_last_claim'] ?? 0;
                $canClaim = (time() - $lastClaim) >= 300; // 5 minutes
                
                echo json_encode([
                    'authenticated' => true,
                    'can_claim' => $canClaim,
                    'seconds_until_claim' => $canClaim ? 0 : (300 - (time() - $lastClaim)),
                    'balance' => $_SESSION['member_balance'] ?? 0.0
                ]);
            } else {
                // Guest mode
                $guestLastClaim = $_SESSION['guest_last_claim'] ?? 0;
                $guestCanClaim = (time() - $guestLastClaim) >= 300; // 5 minutes
                
                echo json_encode([
                    'authenticated' => false,
                    'can_claim' => $guestCanClaim,
                    'seconds_until_claim' => $guestCanClaim ? 0 : (300 - (time() - $guestLastClaim)),
                    'balance' => 0 // Guests don't get balance from faucet API
                ]);
            }
            break;
            
        case 'claim':
            $jwt = $_POST['jwt'] ?? $_GET['jwt'] ?? '';
            $payload = validateJWT($jwt);
            $amount = 100; // Fixed faucet amount
            
            if ($payload) {
                // Member claim
                $lastClaim = $_SESSION['member_last_claim'] ?? 0;
                
                if (time() - $lastClaim < 300) {
                    $remainingTime = 300 - (time() - $lastClaim);
                    echo json_encode([
                        'success' => false,
                        'error' => 'Claim cooldown active',
                        'remaining_seconds' => $remainingTime
                    ]);
                    break;
                }
                
                // Add to member balance and update cooldown
                $_SESSION['member_balance'] = ($_SESSION['member_balance'] ?? 0) + $amount;
                $_SESSION['member_last_claim'] = time();
                
                echo json_encode([
                    'success' => true,
                    'message' => 'Claim successful!',
                    'claimed_amount' => $amount,
                    'new_balance' => $_SESSION['member_balance'],
                    'authenticated' => true
                ]);
                
            } else {
                // Guest claim
                $guestLastClaim = $_SESSION['guest_last_claim'] ?? 0;
                
                if (time() - $guestLastClaim < 300) {
                    $remainingTime = 300 - (time() - $guestLastClaim);
                    echo json_encode([
                        'success' => false,
                        'error' => 'Claim cooldown active',
                        'remaining_seconds' => $remainingTime
                    ]);
                    break;
                }
                
                // Update guest cooldown (guest balance handled by localStorage)
                $_SESSION['guest_last_claim'] = time();
                
                echo json_encode([
                    'success' => true,
                    'message' => 'Claim successful!',
                    'claimed_amount' => $amount,
                    'authenticated' => false
                ]);
            }
            break;
            
        default:
            echo json_encode(['success' => false, 'error' => 'Invalid action']);
    }
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => 'Server error: ' . $e->getMessage()]);
}
?>
