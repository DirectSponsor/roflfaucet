<?php
/**
 * User Data Manager - File-based user data system for ROFLFaucet
 * 
 * Handles user profiles, balances, and activity logs using simple text files
 * with file locking for atomic operations. Designed to work with Syncthing
 * for distributed synchronization across servers.
 */

class UserDataManager {
    private $userDataDir = 'user-data';
    private $usersDir = 'user-data/users';
    private $locksDir = 'user-data/locks';
    private $logsDir = 'user-data/logs';
    private $syncQueueDir = 'user-data/sync-queue';
    private $lockTimeout = 30; // seconds
    
    public function __construct() {
        // Ensure directories exist
        $this->ensureDirectories();
    }
    
    private function ensureDirectories() {
        $dirs = [$this->userDataDir, $this->usersDir, $this->locksDir, 
                $this->logsDir, $this->syncQueueDir];
        foreach ($dirs as $dir) {
            if (!is_dir($dir)) {
                mkdir($dir, 0755, true);
            }
        }
    }
    
    /**
     * Get sanitized filename for a username
     */
    private function getUserFilename($username) {
        // Sanitize username for filename
        $clean = preg_replace('/[^a-zA-Z0-9_-]/', '_', $username);
        return $this->usersDir . '/' . $clean . '.txt';
    }
    
    /**
     * Get lock filename for a username
     */
    private function getLockFilename($username) {
        $clean = preg_replace('/[^a-zA-Z0-9_-]/', '_', $username);
        return $this->locksDir . '/' . $clean . '.lock';
    }
    
    /**
     * Acquire file lock for a user
     */
    private function acquireLock($username, $timeout = null) {
        $timeout = $timeout ?: $this->lockTimeout;
        $lockFile = $this->getLockFilename($username);
        $startTime = time();
        
        while (time() - $startTime < $timeout) {
            if (!file_exists($lockFile)) {
                // Try to create lock file
                $pid = getmypid();
                $timestamp = time();
                $lockData = "pid:$pid\ntimestamp:$timestamp\nsite:roflfaucet\n";
                
                if (file_put_contents($lockFile, $lockData, LOCK_EX) !== false) {
                    return true;
                }
            } else {
                // Check if lock is stale
                if ($this->isLockStale($lockFile)) {
                    unlink($lockFile);
                    continue;
                }
            }
            usleep(100000); // Wait 100ms before retry
        }
        return false;
    }
    
    /**
     * Release file lock for a user
     */
    private function releaseLock($username) {
        $lockFile = $this->getLockFilename($username);
        if (file_exists($lockFile)) {
            unlink($lockFile);
        }
    }
    
    /**
     * Check if a lock file is stale (older than timeout)
     */
    private function isLockStale($lockFile) {
        if (!file_exists($lockFile)) return true;
        
        $lockData = file_get_contents($lockFile);
        if (preg_match('/timestamp:(\d+)/', $lockData, $matches)) {
            $lockTime = intval($matches[1]);
            return (time() - $lockTime) > $this->lockTimeout;
        }
        return true; // Malformed lock file
    }
    
    /**
     * Parse user data from file content
     */
    private function parseUserData($content) {
        $data = [
            'username' => '',
            'balance' => 0,
            'avatar' => 'default.png',
            'profile' => [],
            'metadata' => [],
            'activity' => []
        ];
        
        $lines = explode("\n", $content);
        $currentSection = 'metadata';
        
        foreach ($lines as $line) {
            $line = trim($line);
            if (empty($line)) continue;
            
            // Section headers
            if ($line === '[METADATA]') {
                $currentSection = 'metadata';
                continue;
            } elseif ($line === '[PROFILE]') {
                $currentSection = 'profile';
                continue;
            } elseif ($line === '[ACTIVITY]') {
                $currentSection = 'activity';
                continue;
            }
            
            // Parse data based on section
            if ($currentSection === 'metadata') {
                if (strpos($line, '=') !== false) {
                    list($key, $value) = explode('=', $line, 2);
                    $key = trim($key);
                    $value = trim($value);
                    
                    if ($key === 'username') $data['username'] = $value;
                    elseif ($key === 'balance') $data['balance'] = floatval($value);
                    elseif ($key === 'avatar') $data['avatar'] = $value;
                    else $data['metadata'][$key] = $value;
                }
            } elseif ($currentSection === 'profile') {
                if (strpos($line, '=') !== false) {
                    list($key, $value) = explode('=', $line, 2);
                    $data['profile'][trim($key)] = trim($value);
                }
            } elseif ($currentSection === 'activity') {
                $data['activity'][] = $line;
            }
        }
        
        return $data;
    }
    
    /**
     * Format user data for file storage
     */
    private function formatUserData($data) {
        $content = "[METADATA]\n";
        $content .= "username=" . ($data['username'] ?? '') . "\n";
        $content .= "balance=" . ($data['balance'] ?? 0) . "\n";
        $content .= "avatar=" . ($data['avatar'] ?? 'default.png') . "\n";
        $content .= "created=" . ($data['metadata']['created'] ?? date('Y-m-d H:i:s')) . "\n";
        $content .= "last_activity=" . date('Y-m-d H:i:s') . "\n";
        $content .= "last_site=roflfaucet\n";
        $content .= "version=1\n";
        
        // Add other metadata
        if (isset($data['metadata'])) {
            foreach ($data['metadata'] as $key => $value) {
                if (!in_array($key, ['created', 'last_activity', 'last_site', 'version'])) {
                    $content .= "$key=$value\n";
                }
            }
        }
        
        $content .= "\n[PROFILE]\n";
        if (isset($data['profile'])) {
            foreach ($data['profile'] as $key => $value) {
                $content .= "$key=$value\n";
            }
        }
        
        $content .= "\n[ACTIVITY]\n";
        if (isset($data['activity'])) {
            // Keep only last 50 activity entries to prevent files getting too large
            $activities = array_slice($data['activity'], -50);
            foreach ($activities as $activity) {
                $content .= "$activity\n";
            }
        }
        
        return $content;
    }
    
    /**
     * Get user data, creating file if it doesn't exist
     */
    public function getUser($username) {
        if (empty($username)) {
            return null;
        }
        
        $filename = $this->getUserFilename($username);
        
        // If file doesn't exist, create default user data
        if (!file_exists($filename)) {
            $defaultData = [
                'username' => $username,
                'balance' => 0,
                'avatar' => 'default.png',
                'profile' => [],
                'metadata' => ['created' => date('Y-m-d H:i:s')],
                'activity' => [date('Y-m-d H:i:s') . ' - User account created']
            ];
            
            if ($this->acquireLock($username)) {
                try {
                    $content = $this->formatUserData($defaultData);
                    file_put_contents($filename, $content, LOCK_EX);
                    $this->logActivity("User created: $username");
                } finally {
                    $this->releaseLock($username);
                }
            }
            
            return $defaultData;
        }
        
        // Read existing user data
        $content = file_get_contents($filename);
        return $this->parseUserData($content);
    }
    
    /**
     * Update user balance atomically
     */
    public function updateBalance($username, $newBalance, $operation = 'set', $description = '') {
        if (empty($username)) {
            return false;
        }
        
        if (!$this->acquireLock($username)) {
            $this->logError("Failed to acquire lock for balance update: $username");
            return false;
        }
        
        try {
            $userData = $this->getUser($username);
            $oldBalance = $userData['balance'];
            
            if ($operation === 'add') {
                $userData['balance'] = $oldBalance + $newBalance;
            } elseif ($operation === 'subtract') {
                $userData['balance'] = $oldBalance - $newBalance;
            } else {
                $userData['balance'] = $newBalance;
            }
            
            // Add activity log
            $desc = $description ? " - $description" : '';
            $userData['activity'][] = date('Y-m-d H:i:s') . " - Balance $operation: " . 
                                    "$oldBalance -> {$userData['balance']}$desc";
            
            // Save updated data
            $filename = $this->getUserFilename($username);
            $content = $this->formatUserData($userData);
            file_put_contents($filename, $content, LOCK_EX);
            
            $this->logActivity("Balance update: $username ($operation: $newBalance)");
            return true;
            
        } catch (Exception $e) {
            $this->logError("Balance update failed for $username: " . $e->getMessage());
            return false;
        } finally {
            $this->releaseLock($username);
        }
    }
    
    /**
     * Update user profile data
     */
    public function updateProfile($username, $profileData) {
        if (empty($username)) {
            return false;
        }
        
        if (!$this->acquireLock($username)) {
            return false;
        }
        
        try {
            $userData = $this->getUser($username);
            $userData['profile'] = array_merge($userData['profile'] ?? [], $profileData);
            
            // Add activity log
            $userData['activity'][] = date('Y-m-d H:i:s') . ' - Profile updated';
            
            // Save updated data
            $filename = $this->getUserFilename($username);
            $content = $this->formatUserData($userData);
            file_put_contents($filename, $content, LOCK_EX);
            
            $this->logActivity("Profile update: $username");
            return true;
            
        } catch (Exception $e) {
            $this->logError("Profile update failed for $username: " . $e->getMessage());
            return false;
        } finally {
            $this->releaseLock($username);
        }
    }
    
    /**
     * Get user balance quickly (without full user data)
     */
    public function getBalance($username) {
        if (empty($username)) {
            return 0;
        }
        
        $userData = $this->getUser($username);
        return $userData ? $userData['balance'] : 0;
    }
    
    /**
     * Add activity log entry
     */
    public function addActivity($username, $activity) {
        if (empty($username)) {
            return false;
        }
        
        if (!$this->acquireLock($username)) {
            return false;
        }
        
        try {
            $userData = $this->getUser($username);
            $userData['activity'][] = date('Y-m-d H:i:s') . " - $activity";
            
            // Save updated data
            $filename = $this->getUserFilename($username);
            $content = $this->formatUserData($userData);
            file_put_contents($filename, $content, LOCK_EX);
            
            return true;
            
        } catch (Exception $e) {
            $this->logError("Activity log failed for $username: " . $e->getMessage());
            return false;
        } finally {
            $this->releaseLock($username);
        }
    }
    
    /**
     * Log system activity
     */
    private function logActivity($message) {
        $logFile = $this->logsDir . '/activity.log';
        $timestamp = date('Y-m-d H:i:s');
        file_put_contents($logFile, "[$timestamp] $message\n", FILE_APPEND | LOCK_EX);
    }
    
    /**
     * Log system errors
     */
    private function logError($message) {
        $logFile = $this->logsDir . '/errors.log';
        $timestamp = date('Y-m-d H:i:s');
        file_put_contents($logFile, "[$timestamp] ERROR: $message\n", FILE_APPEND | LOCK_EX);
    }
    
    /**
     * Check if sync is needed (placeholder for future Syncthing integration)
     */
    public function needsSync($username) {
        // For now, always return false since we're running locally
        return false;
    }
    
    /**
     * Get system status
     */
    public function getSystemStatus() {
        $status = [
            'users_count' => count(glob($this->usersDir . '/*.txt')),
            'active_locks' => count(glob($this->locksDir . '/*.lock')),
            'system_healthy' => true,
            'last_activity' => 'Local mode - no sync'
        ];
        
        return $status;
    }
}
?>
