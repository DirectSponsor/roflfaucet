// Slot Machine - Simplified JavaScript for CSS Table Layout
// No complex layout calculations - let CSS table handle everything

class SlotMachine {
    constructor() {
        this.reels = ['reel1', 'reel2', 'reel3'];
        this.symbols = ['🍒', '🍋', '🍊', '🍇', '🔔', '💎', '⭐'];
        this.balance = 100;
        this.isSpinning = false;
        
        this.init();
    }
    
    init() {
        // Get DOM elements
        this.spinBtn = document.getElementById('spin-btn');
        this.betSelect = document.getElementById('bet-amount');
        this.balanceDisplay = document.getElementById('balance');
        this.resultMessage = document.getElementById('result-message');
        
        // Add event listeners
        this.spinBtn.addEventListener('click', () => this.spin());
        
        // Update display
        this.updateBalance();
        
        // Set initial reel dimensions based on viewport
        this.adjustReelSizes();
        window.addEventListener('resize', () => this.adjustReelSizes());
    }
    
    adjustReelSizes() {
        // Simple responsive adjustment - CSS table handles layout distribution
        const viewportWidth = window.innerWidth;
        
        // Just set some basic dimensions, table layout handles the rest
        this.reels.forEach(reelId => {
            const reel = document.getElementById(reelId);
            const strip = reel.querySelector('.reel-strip');
            
            if (viewportWidth < 320) {
                strip.style.minWidth = '60px';
            } else if (viewportWidth < 480) {
                strip.style.minWidth = '80px';
            } else {
                strip.style.minWidth = '100px';
            }
        });
    }
    
    spin() {
        if (this.isSpinning) return;
        
        const bet = parseInt(this.betSelect.value);
        if (this.balance < bet) {
            this.showMessage('Insufficient balance!', 'error');
            return;
        }
        
        this.isSpinning = true;
        this.spinBtn.disabled = true;
        this.balance -= bet;
        this.updateBalance();
        
        // Start spinning animation
        this.reels.forEach(reelId => {
            document.getElementById(reelId).classList.add('spinning');
        });
        
        this.showMessage('Spinning...', 'info');
        
        // Simulate spin duration
        setTimeout(() => {
            this.stopSpin(bet);
        }, 2000 + Math.random() * 1000);
    }
    
    stopSpin(bet) {
        // Stop spinning animation
        this.reels.forEach(reelId => {
            document.getElementById(reelId).classList.remove('spinning');
        });
        
        // Generate random results
        const results = this.reels.map(() => 
            this.symbols[Math.floor(Math.random() * this.symbols.length)]
        );
        
        // Update visible symbols
        this.updateReelSymbols(results);
        
        // Check for wins
        const winAmount = this.checkWin(results, bet);
        if (winAmount > 0) {
            this.balance += winAmount;
            this.showMessage(`WIN! +${winAmount} coins`, 'win');
        } else {
            this.showMessage('No win. Try again!', 'lose');
        }
        
        this.updateBalance();
        this.isSpinning = false;
        this.spinBtn.disabled = false;
    }
    
    updateReelSymbols(results) {
        // Update the center symbol of each reel to show result
        results.forEach((symbol, index) => {
            const reelId = this.reels[index];
            const reel = document.getElementById(reelId);
            const symbols = reel.querySelectorAll('.symbol');
            
            // Find the center symbol (assuming 8 symbols, center is index 3-4)
            const centerSymbol = symbols[3];
            if (centerSymbol) {
                centerSymbol.textContent = symbol;
                centerSymbol.style.background = 'linear-gradient(45deg, #444, #666)';
                centerSymbol.style.transform = 'scale(1.1)';
                
                // Reset styling after animation
                setTimeout(() => {
                    centerSymbol.style.background = 'linear-gradient(45deg, #222, #444)';
                    centerSymbol.style.transform = 'scale(1)';
                }, 500);
            }
        });
    }
    
    checkWin(results, bet) {
        // Simple win logic
        const [r1, r2, r3] = results;
        
        // Three of a kind
        if (r1 === r2 && r2 === r3) {
            const multipliers = {
                '🍒': 10,
                '🍋': 8,
                '🍊': 8,
                '🍇': 6,
                '🔔': 15,
                '💎': 50,
                '⭐': 25
            };
            return bet * (multipliers[r1] || 5);
        }
        
        // Two of a kind
        if (r1 === r2 || r2 === r3 || r1 === r3) {
            return bet * 2;
        }
        
        return 0;
    }
    
    showMessage(message, type = 'info') {
        this.resultMessage.textContent = message;
        this.resultMessage.className = `result-message ${type}`;
        
        // Add some styling based on type
        switch(type) {
            case 'win':
                this.resultMessage.style.color = '#00ff00';
                break;
            case 'lose':
                this.resultMessage.style.color = '#ff6b6b';
                break;
            case 'error':
                this.resultMessage.style.color = '#ff4757';
                break;
            default:
                this.resultMessage.style.color = '#ffd700';
        }
    }
    
    updateBalance() {
        this.balanceDisplay.textContent = this.balance;
    }
}

// Initialize slot machine when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    const slotMachine = new SlotMachine();
    
    // Add some debug info (remove in production)
    console.log('🎰 Slot Machine initialized with CSS table layout');
    console.log('📱 Viewport width:', window.innerWidth);
    console.log('🎲 Table layout will handle responsive behavior automatically');
});

// Add some CSS styles dynamically for better win/lose feedback
document.addEventListener('DOMContentLoaded', () => {
    const style = document.createElement('style');
    style.textContent = `
        .result-message.win {
            animation: winPulse 0.5s ease-in-out;
        }
        
        .result-message.lose {
            animation: loseFade 0.3s ease-in-out;
        }
        
        @keyframes winPulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.1); }
        }
        
        @keyframes loseFade {
            0% { opacity: 1; }
            50% { opacity: 0.5; }
            100% { opacity: 1; }
        }
    `;
    document.head.appendChild(style);
});
