<?php
/**
 * Ultra-Simple Session Balance API
 * Mirrors localStorage operations exactly - just using PHP sessions instead
 */

session_start();
header('Content-Type: application/json');

// Get the action
$action = $_GET['action'] ?? $_POST['action'] ?? '';

// Simple JWT check (just verify token exists and isn't expired)
function isValidJWT($jwt) {
    if (!$jwt) return false;
    
    try {
        $parts = explode('.', $jwt);
        if (count($parts) !== 3) return false;
        
        $payload = json_decode(base64_decode($parts[1]), true);
        if (isset($payload['exp']) && $payload['exp'] < time()) {
            return false;
        }
        
        return true;
    } catch (Exception $e) {
        return false;
    }
}

try {
    switch ($action) {
        case 'get':
            // Get balance - just like localStorage.getItem('guest_balance')
            $balance = $_SESSION['member_balance'] ?? 0.0;
            echo json_encode([
                'success' => true,
                'balance' => $balance
            ]);
            break;
            
        case 'add':
            // Add balance - just like guest localStorage operations
            $jwt = $_POST['jwt'] ?? '';
            $amount = floatval($_POST['amount'] ?? 0);
            
            if (!isValidJWT($jwt)) {
                echo json_encode(['success' => false, 'error' => 'Invalid token']);
                break;
            }
            
            if ($amount <= 0) {
                echo json_encode(['success' => false, 'error' => 'Invalid amount']);
                break;
            }
            
            // Initialize if not set
            $currentBalance = $_SESSION['member_balance'] ?? 0.0;
            $newBalance = $currentBalance + $amount;
            $_SESSION['member_balance'] = $newBalance;
            
            echo json_encode([
                'success' => true,
                'old_balance' => $currentBalance,
                'new_balance' => $newBalance,
                'amount_added' => $amount
            ]);
            break;
            
        case 'subtract':
            // Subtract balance - just like guest localStorage operations
            $jwt = $_POST['jwt'] ?? '';
            $amount = floatval($_POST['amount'] ?? 0);
            
            if (!isValidJWT($jwt)) {
                echo json_encode(['success' => false, 'error' => 'Invalid token']);
                break;
            }
            
            if ($amount <= 0) {
                echo json_encode(['success' => false, 'error' => 'Invalid amount']);
                break;
            }
            
            // Initialize if not set
            $currentBalance = $_SESSION['member_balance'] ?? 0.0;
            
            // Check sufficient balance (just like guest system)
            if ($currentBalance < $amount) {
                echo json_encode([
                    'success' => false,
                    'error' => 'Insufficient balance',
                    'current_balance' => $currentBalance
                ]);
                break;
            }
            
            $newBalance = $currentBalance - $amount;
            $_SESSION['member_balance'] = $newBalance;
            
            echo json_encode([
                'success' => true,
                'old_balance' => $currentBalance,
                'new_balance' => $newBalance,
                'amount_subtracted' => $amount
            ]);
            break;
            
        default:
            echo json_encode(['success' => false, 'error' => 'Invalid action']);
    }
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => 'Server error: ' . $e->getMessage()]);
}
?>
