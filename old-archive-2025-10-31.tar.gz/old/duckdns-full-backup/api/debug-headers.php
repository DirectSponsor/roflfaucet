<?php
header('Content-Type: application/json');

// Debug: Show all headers received by PHP
$headers = [];
foreach($_SERVER as $key => $value) {
    if (strpos($key, 'HTTP_') === 0) {
        $headers[$key] = $value;
    }
}

$response = [
    'all_headers' => $headers,
    'authorization_header' => $_SERVER['HTTP_AUTHORIZATION'] ?? 'NOT_FOUND',
    'request_method' => $_SERVER['REQUEST_METHOD'],
    'query_string' => $_SERVER['QUERY_STRING'] ?? '',
    'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'NOT_FOUND'
];

echo json_encode($response, JSON_PRETTY_PRINT);
?>
