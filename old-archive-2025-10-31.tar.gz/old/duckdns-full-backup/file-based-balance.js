/**
 * File-based Balance System - Client-side JavaScript
 * 
 * Replaces session-based balance with persistent file-based storage.
 * Works with user-data-api.php for authenticated users.
 * Falls back to localStorage for guests (unchanged from simple-balance.js).
 */

class FileBasedBalance {
    constructor() {
        this.apiUrl = 'user-data-api.php';
        this.isGuest = true;
        this.username = null;
        this.token = null;
        this.balance = 0;
        
        this.init();
    }
    
    init() {
        // Check if user is logged in
        this.token = localStorage.getItem('jwt_token');
        if (this.token) {
            this.validateToken();
        } else {
            this.initGuestMode();
        }
    }
    
    async validateToken() {
        try {
            const response = await fetch(`${this.apiUrl}?action=balance`, {
                headers: {
                    'Authorization': `Bearer ${this.token}`,
                    'Content-Type': 'application/json'
                }
            });
            
            if (response.ok) {
                const data = await response.json();
                this.isGuest = false;
                this.username = data.username;
                this.balance = data.balance;
                console.log(`File-based balance initialized for user: ${this.username}, balance: ${this.balance}`);
                // Force balance display update
                setTimeout(() => this.updateBalanceDisplays(), 50);
            } else {
                // Token invalid, fall back to guest mode
                localStorage.removeItem('jwt_token');
                this.initGuestMode();
            }
        } catch (error) {
            console.error('Error validating token:', error);
            this.initGuestMode();
        }
    }
    
    initGuestMode() {
        this.isGuest = true;
        this.username = null;
        this.token = null;
        this.balance = parseFloat(localStorage.getItem('guestBalance') || '0');
        console.log(`File-based balance initialized for guest, balance: ${this.balance}`);
        // Force balance display update for guests too
        setTimeout(() => this.updateBalanceDisplays(), 50);
    }
    
    // Public API methods
    async getBalance() {
        if (this.isGuest) {
            return this.balance;
        }
        
        try {
            const response = await fetch(`${this.apiUrl}?action=balance`, {
                headers: {
                    'Authorization': `Bearer ${this.token}`,
                    'Content-Type': 'application/json'
                }
            });
            
            if (response.ok) {
                const data = await response.json();
                this.balance = data.balance;
                return this.balance;
            } else {
                console.error('Failed to fetch balance');
                return this.balance; // Return cached balance
            }
        } catch (error) {
            console.error('Error fetching balance:', error);
            return this.balance; // Return cached balance
        }
    }
    
    async addBalance(amount, description = '') {
        if (this.isGuest) {
            this.balance += amount;
            localStorage.setItem('guestBalance', this.balance.toString());
            this.updateBalanceDisplays();
            return true;
        }
        
        try {
            const response = await fetch(`${this.apiUrl}?action=update_balance`, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${this.token}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    amount: amount,
                    operation: 'add',
                    description: description
                })
            });
            
            if (response.ok) {
                const data = await response.json();
                this.balance = data.balance;
                this.updateBalanceDisplays();
                return true;
            } else {
                console.error('Failed to add balance');
                return false;
            }
        } catch (error) {
            console.error('Error adding balance:', error);
            return false;
        }
    }
    
    async subtractBalance(amount, description = '') {
        if (this.isGuest) {
            if (this.balance >= amount) {
                this.balance -= amount;
                localStorage.setItem('guestBalance', this.balance.toString());
                this.updateBalanceDisplays();
                return true;
            }
            return false; // Insufficient funds
        }
        
        try {
            const response = await fetch(`${this.apiUrl}?action=update_balance`, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${this.token}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    amount: amount,
                    operation: 'subtract',
                    description: description
                })
            });
            
            if (response.ok) {
                const data = await response.json();
                this.balance = data.balance;
                this.updateBalanceDisplays();
                return true;
            } else {
                console.error('Failed to subtract balance');
                return false;
            }
        } catch (error) {
            console.error('Error subtracting balance:', error);
            return false;
        }
    }
    
    async setBalance(amount, description = '') {
        if (this.isGuest) {
            this.balance = amount;
            localStorage.setItem('guestBalance', this.balance.toString());
            this.updateBalanceDisplays();
            return true;
        }
        
        try {
            const response = await fetch(`${this.apiUrl}?action=update_balance`, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${this.token}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    amount: amount,
                    operation: 'set',
                    description: description
                })
            });
            
            if (response.ok) {
                const data = await response.json();
                this.balance = data.balance;
                this.updateBalanceDisplays();
                return true;
            } else {
                console.error('Failed to set balance');
                return false;
            }
        } catch (error) {
            console.error('Error setting balance:', error);
            return false;
        }
    }
    
    // Update all balance displays on the page
    updateBalanceDisplays() {
        const balanceElements = document.querySelectorAll('.balance-display, .user-balance, #balance, #userBalance, .balance');
        const formattedBalance = this.balance.toFixed(2);
        
        balanceElements.forEach(element => {
            if (element.tagName === 'INPUT') {
                element.value = formattedBalance;
            } else {
                element.textContent = formattedBalance;
            }
        });
        
        // Update currency displays
        const currencyElements = document.querySelectorAll('.currency-display, .currency');
        currencyElements.forEach(element => {
            element.textContent = this.isGuest ? 'tokens' : 'coins';
        });
        
        // Update full currency name displays
        const currencyFullElements = document.querySelectorAll('.currency-full');
        currencyFullElements.forEach(element => {
            element.textContent = this.isGuest ? 'tokens' : 'coins';
        });
        
        // Update uppercase currency displays
        const currencyUpperElements = document.querySelectorAll('.currency-upper');
        currencyUpperElements.forEach(element => {
            element.textContent = this.isGuest ? 'TOKENS' : 'COINS';
        });
        
        console.log(`💰 Balance displays updated: ${formattedBalance} ${this.isGuest ? 'tokens' : 'coins'} (isGuest: ${this.isGuest})`);
    }
    
    // Get user profile (members only)
    async getProfile() {
        if (this.isGuest) {
            return null;
        }
        
        try {
            const response = await fetch(`${this.apiUrl}?action=profile`, {
                headers: {
                    'Authorization': `Bearer ${this.token}`,
                    'Content-Type': 'application/json'
                }
            });
            
            if (response.ok) {
                return await response.json();
            } else {
                console.error('Failed to fetch profile');
                return null;
            }
        } catch (error) {
            console.error('Error fetching profile:', error);
            return null;
        }
    }
    
    // Update user profile (members only)
    async updateProfile(profileData) {
        if (this.isGuest) {
            return false;
        }
        
        try {
            const response = await fetch(`${this.apiUrl}?action=update_profile`, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${this.token}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    profile: profileData
                })
            });
            
            return response.ok;
        } catch (error) {
            console.error('Error updating profile:', error);
            return false;
        }
    }
    
    // Get recent activity (members only)
    async getActivity() {
        if (this.isGuest) {
            return [];
        }
        
        try {
            const response = await fetch(`${this.apiUrl}?action=activity`, {
                headers: {
                    'Authorization': `Bearer ${this.token}`,
                    'Content-Type': 'application/json'
                }
            });
            
            if (response.ok) {
                const data = await response.json();
                return data.activities || [];
            } else {
                console.error('Failed to fetch activity');
                return [];
            }
        } catch (error) {
            console.error('Error fetching activity:', error);
            return [];
        }
    }
    
    // Add activity log entry (members only)
    async addActivity(activity) {
        if (this.isGuest) {
            return false;
        }
        
        try {
            const response = await fetch(`${this.apiUrl}?action=add_activity`, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${this.token}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    activity: activity
                })
            });
            
            return response.ok;
        } catch (error) {
            console.error('Error adding activity:', error);
            return false;
        }
    }
    
    // Handle user login (switch from guest to member mode)
    async handleLogin(token) {
        this.token = token;
        localStorage.setItem('jwt_token', token);
        await this.validateToken();
        this.updateBalanceDisplays();
    }
    
    // Handle user logout (switch to guest mode)
    handleLogout() {
        localStorage.removeItem('jwt_token');
        this.initGuestMode();
        this.updateBalanceDisplays();
    }
    
    // Get system status (for debugging)
    async getSystemStatus() {
        try {
            const response = await fetch(`${this.apiUrl}?action=status`);
            if (response.ok) {
                return await response.json();
            }
        } catch (error) {
            console.error('Error fetching system status:', error);
        }
        return null;
    }
    
    // Public getter methods
    isUserGuest() {
        return this.isGuest;
    }
    
    getUsername() {
        return this.username;
    }
    
    getCurrentBalance() {
        return this.balance;
    }
}

// Initialize the global balance system
const fileBasedBalance = new FileBasedBalance();

// Global convenience functions (for compatibility with existing code)
window.getBalance = () => fileBasedBalance.getCurrentBalance();
window.addBalance = (amount, description) => fileBasedBalance.addBalance(amount, description);
window.subtractBalance = (amount, description) => fileBasedBalance.subtractBalance(amount, description);
window.setBalance = (amount, description) => fileBasedBalance.setBalance(amount, description);
window.updateBalanceDisplays = () => fileBasedBalance.updateBalanceDisplays();

// Legacy function names for compatibility
window.addRealBalance = window.addBalance;
window.subtractRealBalance = window.subtractBalance;

// Login/logout handlers
window.handleUserLogin = (token) => fileBasedBalance.handleLogin(token);
window.handleUserLogout = () => fileBasedBalance.handleLogout();

// Initialize balance displays on page load
document.addEventListener('DOMContentLoaded', () => {
    setTimeout(() => {
        fileBasedBalance.updateBalanceDisplays();
    }, 100);
});

console.log('File-based balance system loaded');
