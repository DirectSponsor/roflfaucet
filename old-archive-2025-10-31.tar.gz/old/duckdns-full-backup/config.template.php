<?php
/**
 * ROFLFaucet Configuration Template
 * 
 * This file contains placeholder values and is safe to commit to git.
 * Copy this to config.php and fill in the real values for production.
 * 
 * NEVER COMMIT config.php TO GIT!
 */

// Database Configuration
define('DB_HOST', 'localhost');
define('DB_NAME', 'your_database_name');
define('DB_USER', 'your_database_user');
define('DB_PASS', 'your_database_password');

// JWT Configuration
define('JWT_SECRET', 'your_jwt_secret_key_change_this_in_production');

// Site Configuration
define('SITE_ID', 'roflfaucet');
define('SITE_URL', 'https://roflfaucet.com');

// OAuth Server Configuration (if used)
define('AUTH_SERVER', 'http://auth.directsponsor.org');
define('DATA_SERVER', 'http://data.directsponsor.org');

// Security Settings
define('SESSION_TIMEOUT', 3600); // 1 hour
define('CLAIM_COOLDOWN', 300);   // 5 minutes

// Debug mode (set to false in production)
define('DEBUG_MODE', false);

// Email Configuration (if needed)
define('SMTP_HOST', 'your_smtp_host');
define('SMTP_PORT', 587);
define('SMTP_USER', 'your_smtp_user');
define('SMTP_PASS', 'your_smtp_password');
define('FROM_EMAIL', 'noreply@roflfaucet.com');

?>
