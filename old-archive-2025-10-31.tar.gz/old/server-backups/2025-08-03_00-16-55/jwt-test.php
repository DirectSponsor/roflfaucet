<?php echo "JWT test endpoint working"; ?>
