# WebSocket Chat System Backup

This directory contains the original WebSocket-based chat system for ROFLFaucet.

## Files Backed Up:
- `chat-server-advanced.js` - Node.js WebSocket server
- `roflfaucet-chat.service` - Systemd service file
- `chat-widget.js` - Frontend WebSocket chat widget
- `chat-integration.js` - Integration with main site
- `deploy-chat.sh` - Deployment script

## To Restore WebSocket System:
1. Copy files back to main directory
2. Install Node.js dependencies: `npm install ws`
3. Deploy with: `./deploy-chat.sh`
4. The system runs on port 8081 with WebSocket path `/chat`

## System Details:
- **Server**: Node.js with 'ws' library
- **Port**: 8081
- **Path**: `/chat`
- **Features**: Real-time chat, tips, rain system, multiple rooms
- **Memory Usage**: ~46MB constant
- **Backup Date**: 2025-08-03

## Why Replaced:
- Node.js shutdown/restart reliability issues
- Systemctl service management problems
- Switched to PHP polling system for better reliability
